(function() {
	//#region src/shared/hostApi.ts
	var api = require("any-listen");
	var console = {
		log: api.logcat.info,
		error: api.logcat.error,
		warn: api.logcat.warn
	};
	api.env.version;
	var extensionVersion = api.env.extensionVersion;
	var registerResourceAction = api.registerResourceAction;
	var player = api.player;
	var musicList = api.musicList;
	var configuration = api.configuration;
	var app = api.app;
	var storage = api.storage;
	var command = api.command;
	var request = api.request;
	api.t;
	api.utils.crypto;
	var dataConverter = api.utils.dataConverter;
	api.utils.iconv;
	api.utils.zlib;
	//#endregion
	//#region src/shared/searchPagination.ts
	/** Paginate the records actually returned by an API that provides no total. */
	function createSearchPagination(fetchBatch, getId, onPartialError = () => {}) {
		const items = [];
		const ids = /* @__PURE__ */ new Set();
		let nextApiPage = 1;
		let exhausted = false;
		let pending;
		const loadNextBatch = () => {
			if (pending) return pending;
			pending = fetchBatch(nextApiPage).then((batch) => {
				if (!batch.length) throw new Error("搜索返回空结果(可能是 API 限流,请稍后重试)");
				const newItems = batch.filter((item) => {
					const id = getId(item);
					if (ids.has(id)) return false;
					ids.add(id);
					return true;
				});
				if (!newItems.length) exhausted = true;
				items.push(...newItems);
				nextApiPage++;
			}).finally(() => {
				pending = void 0;
			});
			return pending;
		};
		return { async getPage(page, limit) {
			const start = (page - 1) * limit;
			const end = start + limit;
			try {
				while (items.length < end && !exhausted) await loadNextBatch();
			} catch (error) {
				if (start >= items.length) throw error;
				onPartialError(error);
			}
			return {
				list: items.slice(start, end),
				total: exhausted ? items.length : Math.ceil(items.length / limit) * limit + 1
			};
		} };
	}
	//#endregion
	//#region src/identity.ts
	var gdSources = [
		["netease", "网易云音乐"],
		["kuwo", "酷我音乐"],
		["joox", "JOOX"],
		["tencent", "QQ音乐"],
		["tidal", "TIDAL"],
		["qobuz", "QOBUZ"],
		["bilibili", "哔哩哔哩"],
		["apple", "Apple Music"],
		["ytmusic", "YouTube Music"],
		["spotify", "Spotify"]
	];
	var sourceSet = new Set(gdSources.map(([source]) => source));
	var toHostSource = (source) => `gd-${source}`;
	var toGdSource = (source) => {
		const value = source.startsWith("gd-") || source.startsWith("gd_") ? source.slice(3) : source;
		return sourceSet.has(value) ? value : null;
	};
	var getGdSource = (source) => {
		const value = toGdSource(source);
		if (!value) throw new Error(`Unsupported GD source: ${source}`);
		return value;
	};
	var isLegacySource = (source) => sourceSet.has(source);
	var buildMusicId = (source, rawId) => `gd:v1:${source}:${rawId}`;
	var getRawMusicId = (musicInfo) => {
		const meta = musicInfo.meta;
		if (typeof meta?.musicId === "string" && meta.musicId) return meta.musicId;
		return typeof musicInfo.id === "string" || typeof musicInfo.id === "number" ? String(musicInfo.id) : "";
	};
	//#endregion
	//#region node_modules/.pnpm/fflate@0.8.3/node_modules/fflate/esm/browser.js
	var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
	var fleb = new u8([
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		2,
		2,
		2,
		2,
		3,
		3,
		3,
		3,
		4,
		4,
		4,
		4,
		5,
		5,
		5,
		5,
		0,
		0,
		0,
		0
	]);
	var fdeb = new u8([
		0,
		0,
		0,
		0,
		1,
		1,
		2,
		2,
		3,
		3,
		4,
		4,
		5,
		5,
		6,
		6,
		7,
		7,
		8,
		8,
		9,
		9,
		10,
		10,
		11,
		11,
		12,
		12,
		13,
		13,
		0,
		0
	]);
	var clim = new u8([
		16,
		17,
		18,
		0,
		8,
		7,
		9,
		6,
		10,
		5,
		11,
		4,
		12,
		3,
		13,
		2,
		14,
		1,
		15
	]);
	var freb = function(eb, start) {
		var b = new u16(31);
		for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
		var r = new i32(b[30]);
		for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
		return {
			b,
			r
		};
	};
	var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
	fl[28] = 258, revfl[258] = 28;
	var _b = freb(fdeb, 0), fd = _b.b;
	_b.r;
	var rev = new u16(32768);
	for (var i = 0; i < 32768; ++i) {
		var x = (i & 43690) >> 1 | (i & 21845) << 1;
		x = (x & 52428) >> 2 | (x & 13107) << 2;
		x = (x & 61680) >> 4 | (x & 3855) << 4;
		rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
	}
	var hMap = (function(cd, mb, r) {
		var s = cd.length;
		var i = 0;
		var l = new u16(mb);
		for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
		var le = new u16(mb);
		for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
		var co;
		if (r) {
			co = new u16(1 << mb);
			var rvb = 15 - mb;
			for (i = 0; i < s; ++i) if (cd[i]) {
				var sv = i << 4 | cd[i];
				var r_1 = mb - cd[i];
				var v = le[cd[i] - 1]++ << r_1;
				for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
			}
		} else {
			co = new u16(s);
			for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
		}
		return co;
	});
	var flt = new u8(288);
	for (var i = 0; i < 144; ++i) flt[i] = 8;
	for (var i = 144; i < 256; ++i) flt[i] = 9;
	for (var i = 256; i < 280; ++i) flt[i] = 7;
	for (var i = 280; i < 288; ++i) flt[i] = 8;
	var fdt = new u8(32);
	for (var i = 0; i < 32; ++i) fdt[i] = 5;
	var flrm = /* @__PURE__ */ hMap(flt, 9, 1), fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
	var max = function(a) {
		var m = a[0];
		for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
		return m;
	};
	var bits = function(d, p, m) {
		var o = p / 8 | 0;
		return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
	};
	var bits16 = function(d, p) {
		var o = p / 8 | 0;
		return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
	};
	var shft = function(p) {
		return (p + 7) / 8 | 0;
	};
	var slc = function(v, s, e) {
		if (s == null || s < 0) s = 0;
		if (e == null || e > v.length) e = v.length;
		return new u8(v.subarray(s, e));
	};
	var ec = [
		"unexpected EOF",
		"invalid block type",
		"invalid length/literal",
		"invalid distance",
		"stream finished",
		"no stream handler",
		,
		"no callback",
		"invalid UTF-8 data",
		"extra field too long",
		"date not in range 1980-2099",
		"filename too long",
		"stream finishing",
		"invalid zip data"
	];
	var err = function(ind, msg, nt) {
		var e = new Error(msg || ec[ind]);
		e.code = ind;
		if (Error.captureStackTrace) Error.captureStackTrace(e, err);
		if (!nt) throw e;
		return e;
	};
	var inflt = function(dat, st, buf, dict) {
		var sl = dat.length, dl = dict ? dict.length : 0;
		if (!sl || st.f && !st.l) return buf || new u8(0);
		var noBuf = !buf;
		var resize = noBuf || st.i != 2;
		var noSt = st.i;
		if (noBuf) buf = new u8(sl * 3);
		var cbuf = function(l) {
			var bl = buf.length;
			if (l > bl) {
				var nbuf = new u8(Math.max(bl * 2, l));
				nbuf.set(buf);
				buf = nbuf;
			}
		};
		var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
		var tbts = sl * 8;
		do {
			if (!lm) {
				final = bits(dat, pos, 1);
				var type = bits(dat, pos + 1, 3);
				pos += 3;
				if (!type) {
					var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
					if (t > sl) {
						if (noSt) err(0);
						break;
					}
					if (resize) cbuf(bt + l);
					buf.set(dat.subarray(s, t), bt);
					st.b = bt += l, st.p = pos = t * 8, st.f = final;
					continue;
				} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
				else if (type == 2) {
					var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
					var tl = hLit + bits(dat, pos + 5, 31) + 1;
					pos += 14;
					var ldt = new u8(tl);
					var clt = new u8(19);
					for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
					pos += hcLen * 3;
					var clb = max(clt), clbmsk = (1 << clb) - 1;
					var clm = hMap(clt, clb, 1);
					for (var i = 0; i < tl;) {
						var r = clm[bits(dat, pos, clbmsk)];
						pos += r & 15;
						var s = r >> 4;
						if (s < 16) ldt[i++] = s;
						else {
							var c = 0, n = 0;
							if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
							else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
							else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
							while (n--) ldt[i++] = c;
						}
					}
					var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
					lbt = max(lt);
					dbt = max(dt);
					lm = hMap(lt, lbt, 1);
					dm = hMap(dt, dbt, 1);
				} else err(1);
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
			}
			if (resize) cbuf(bt + 131072);
			var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
			var lpos = pos;
			for (;; lpos = pos) {
				var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
				pos += c & 15;
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (!c) err(2);
				if (sym < 256) buf[bt++] = sym;
				else if (sym == 256) {
					lpos = pos, lm = null;
					break;
				} else {
					var add = sym - 254;
					if (sym > 264) {
						var i = sym - 257, b = fleb[i];
						add = bits(dat, pos, (1 << b) - 1) + fl[i];
						pos += b;
					}
					var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
					if (!d) err(3);
					pos += d & 15;
					var dt = fd[dsym];
					if (dsym > 3) {
						var b = fdeb[dsym];
						dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
					}
					if (pos > tbts) {
						if (noSt) err(0);
						break;
					}
					if (resize) cbuf(bt + 131072);
					var end = bt + add;
					if (bt < dt) {
						var shift = dl - dt, dend = Math.min(dt, end);
						if (shift + bt < 0) err(3);
						for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
					}
					for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
				}
			}
			st.l = lm, st.p = lpos, st.b = bt, st.f = final;
			if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
		} while (!final);
		return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
	};
	var et = /* @__PURE__ */ new u8(0);
	var gzs = function(d) {
		if (d[0] != 31 || d[1] != 139 || d[2] != 8) err(6, "invalid gzip data");
		var flg = d[3];
		var st = 10;
		if (flg & 4) st += (d[10] | d[11] << 8) + 2;
		for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++]);
		return st + (flg & 2);
	};
	var gzl = function(d) {
		var l = d.length;
		return (d[l - 4] | d[l - 3] << 8 | d[l - 2] << 16 | d[l - 1] << 24) >>> 0;
	};
	function gunzipSync(data, opts) {
		var st = gzs(data);
		if (st + 8 > data.length) err(6, "invalid gzip data");
		return inflt(data.subarray(st, -8), { i: 2 }, opts && opts.out || new u8(gzl(data)), opts && opts.dictionary);
	}
	var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
	try {
		td.decode(et, { stream: true });
	} catch (e) {}
	//#endregion
	//#region src/migration.ts
	var REPORT_PATH = "migration/last-report.json";
	var OUTPUT_NAME = "any-listen.gdstudio-v1.migrated.json";
	var migrationPrompt;
	var getBackupLists = (data) => [
		data.defaultList,
		data.loveList,
		...data.userList
	];
	var toBytes = (file) => {
		if (typeof file !== "string") return new Uint8Array(file);
		const bytes = new Uint8Array(file.length);
		for (let i = 0; i < file.length; i++) bytes[i] = file.charCodeAt(i);
		return bytes;
	};
	var readBackup = async (path) => {
		const file = toBytes(await app.readOpenDialogFile(path, "binary"));
		const content = file[0] === 31 && file[1] === 139 ? gunzipSync(file) : file;
		return JSON.parse(await dataConverter(content, "utf-8"));
	};
	var migrateBackup = (backup) => {
		if (backup.songlist?.version !== 1 || !backup.songlist.data) throw new Error("这不是受支持的 Any Listen 歌单备份");
		const sourceCounts = {};
		let changed = 0;
		let duplicates = 0;
		const lists = getBackupLists(backup.songlist.data);
		for (const list of lists) {
			const ids = /* @__PURE__ */ new Set();
			const migrated = [];
			for (const music of list.list) {
				if (music.isLocal) {
					migrated.push(music);
					ids.add(music.id);
					continue;
				}
				const source = toGdSource(music.meta.source);
				if (!source) {
					migrated.push(music);
					ids.add(music.id);
					continue;
				}
				const rawId = String(music.meta.musicId || music.id);
				const id = buildMusicId(source, rawId);
				const hostSource = toHostSource(source);
				if (ids.has(id)) {
					duplicates++;
					continue;
				}
				ids.add(id);
				migrated.push({
					...music,
					id,
					meta: {
						...music.meta,
						source: hostSource,
						musicId: rawId,
						gdSource: source,
						gdIdentityVersion: 1
					}
				});
				if (music.id !== id || music.meta.source !== hostSource) {
					changed++;
					sourceCounts[source] = (sourceCounts[source] ?? 0) + 1;
				}
			}
			list.list = migrated;
			list.meta.songCount = migrated.length;
		}
		return {
			report: {
				createdAt: Date.now(),
				changed,
				duplicates,
				lists: lists.length,
				sources: sourceCounts
			},
			backup
		};
	};
	var reportText = (report) => {
		const sourceLines = Object.entries(report.sources).map(([source, count]) => `${source}: ${count}`).join("\n");
		return `待转换歌曲：${report.changed}\n合并重复歌曲：${report.duplicates}\n扫描歌单：${report.lists}${sourceLines ? `\n\n${sourceLines}` : ""}`;
	};
	var migrateSelectedBackup = async () => {
		const files = await app.showOpenDialog({
			title: "选择 Any Listen 歌单备份",
			filters: { "Any Listen 备份": ["alcfg", "json"] },
			canSelectFiles: true
		});
		if (!files.length) return;
		const { backup, report } = migrateBackup(await readBackup(files[0]));
		if (!report.changed && !report.duplicates) {
			await app.showMessage("备份中没有需要升级的 GD音乐台歌曲。", {
				modal: true,
				type: "info"
			});
			return;
		}
		if (await app.showMessage(reportText(report), {
			modal: true,
			type: "warning",
			buttons: [{ text: "生成迁移文件" }, { text: "取消" }]
		}) !== 0) return;
		const saveOptions = {
			title: "保存迁移后的歌单备份",
			defaultFileName: OUTPUT_NAME,
			filters: { JSON: ["json"] },
			canSelectFolder: true
		};
		const dir = await app.showSaveDialog(saveOptions);
		if (!dir) return;
		const outputPath = await app.writeSaveDialogFile(dir, OUTPUT_NAME, JSON.stringify(backup));
		await storage.writeFile(REPORT_PATH, JSON.stringify(report, null, 2));
		await app.showMessage(`迁移文件已保存：${outputPath}\n\n请在 Any Listen 的“备份与恢复”中导入该文件，并选择完整覆盖本地歌单。更新数据后，建议清理一次缓存并清空旧播放队列。`, {
			modal: true,
			type: "info"
		});
	};
	var runBackupMigration = async () => {
		try {
			await migrateSelectedBackup();
		} catch (err) {
			console.error("[gdstudio] Backup migration failed:", err);
			await app.showMessage(`迁移失败：${err instanceof Error ? err.message : String(err)}`, {
				modal: true,
				type: "error"
			});
		}
	};
	var showLastReport = async () => {
		if (!await storage.fileExists(REPORT_PATH)) {
			await app.showMessage("还没有生成过迁移报告。", {
				modal: true,
				type: "info"
			});
			return;
		}
		const report = JSON.parse(await storage.readFile(REPORT_PATH, "utf-8"));
		await app.showMessage(reportText(report), {
			modal: true,
			type: "info",
			textSelect: true
		});
	};
	var promptLegacyMigration = async () => {
		if (migrationPrompt) return migrationPrompt;
		migrationPrompt = (async () => {
			if (typeof player?.playerAction === "function") await player.playerAction({ action: "stop" }).catch(() => {});
			const action = await app.showMessage("检测到旧版 GD音乐台歌曲。请导出 Any Listen 歌单备份，再由插件生成迁移文件。", {
				modal: true,
				type: "warning",
				buttons: [
					{ text: "选择已导出的备份" },
					{ text: "查看导出步骤" },
					{ text: "关闭" }
				]
			});
			if (action === 0) await runBackupMigration();
			if (action === 1) await app.showMessage("请打开 Any Listen 设置，进入“备份与恢复”，导出包含歌单的 .alcfg 文件，然后运行“迁移旧版歌单数据”。", {
				modal: true,
				type: "info"
			});
		})().finally(() => {
			migrationPrompt = void 0;
		});
		return migrationPrompt;
	};
	var setupMigrationCommands = async () => {
		await command.registerCommand("migrateLegacyData", runBackupMigration);
		await command.registerCommand("showMigrationReport", showLastReport);
		console.log(`[gdstudio] Identity migration ready for ${gdSources.length} sources`);
	};
	var shouldRejectLegacySource = (source) => isLegacySource(source);
	//#endregion
	//#region src/signServerSettings.ts
	var KEEP_DIALOG_OPEN = "\xA0";
	var activeDialog;
	var parseInstruction = (instruction) => {
		const separator = instruction.indexOf(":");
		if (separator < 0) return;
		const name = instruction.slice(0, separator).trim();
		const value = instruction.slice(separator + 1).trim();
		switch (name) {
			case "useOrgSource":
				if (value !== "true" && value !== "false") return;
				return { useOrgSource: value === "true" };
			case "setSignServer": return { signServerUrl: value };
			case "setSignToken": return { signKey: value };
		}
	};
	var saveInstruction = async (instruction) => {
		const update = parseInstruction(instruction);
		if (!update) return "无效指令";
		try {
			await configuration.setConfigs(update);
		} catch {
			console.error("[gdstudio] Failed to save maintenance instruction");
			return "保存失败，请重试";
		}
		app.showMessage("已保存", { type: "info" }).catch(() => {});
		return KEEP_DIALOG_OPEN;
	};
	var openMaintenanceDialog = async () => {
		let pendingSave = Promise.resolve();
		try {
			await app.showInputDialog({
				value: "",
				validateInput: (instruction) => {
					const result = pendingSave.then(() => saveInstruction(instruction));
					pendingSave = result.catch(() => {});
					return result;
				}
			});
		} catch (error) {
			if (error?.message === "canceled") return;
			console.error("[gdstudio] Failed to open maintenance dialog");
		}
	};
	var setupSignServerSettingsCommand = async () => {
		await command.registerCommand("configureSignServer", () => {
			activeDialog ??= openMaintenanceDialog().finally(() => {
				activeDialog = void 0;
			});
			return activeDialog;
		});
	};
	//#endregion
	//#region publish/changeLog.md?raw
	var changeLog_default = "由于相关讨论过多，移除签名服务器\n";
	//#endregion
	//#region src/updateNotice.ts
	var LAST_SHOWN_VERSION_PATH = "update-notice/last-shown-version";
	var showUpdateNotice = async () => {
		if ((await storage.fileExists(LAST_SHOWN_VERSION_PATH) ? await storage.readFile(LAST_SHOWN_VERSION_PATH, "utf-8") : "") === extensionVersion) return;
		await app.showMessage(`${extensionVersion} 更新内容：\n\n${changeLog_default.trim()}`, {
			modal: true,
			type: "info",
			textSelect: true
		});
		await storage.writeFile(LAST_SHOWN_VERSION_PATH, extensionVersion);
	};
	//#endregion
	//#region src/index.ts
	var MAIN_API_URL = "https://music-api.gdstudio.xyz/api.php";
	var CONFIG_PRELOAD_QUALITY_ON_SEARCH = "preloadQualityOnSearch";
	var CONFIG_USE_ORG_SOURCE = "useOrgSource";
	var ORG_SOURCES = new Set([
		"tencent",
		"tidal",
		"qobuz",
		"apple",
		"ytmusic",
		"spotify"
	]);
	var CONFIG_SIGN_SERVER_URL = "signServerUrl";
	var CONFIG_SIGN_KEY = "signKey";
	var preloadQualityOnSearch = true;
	var useOrgSource = false;
	var signServerUrl = "";
	var signKey = "";
	var isOrgSource = (source) => {
		const value = String(source || "");
		return useOrgSource || ORG_SOURCES.has(toGdSource(value) || value);
	};
	var configReady = configuration?.getConfigs?.([
		CONFIG_PRELOAD_QUALITY_ON_SEARCH,
		CONFIG_SIGN_SERVER_URL,
		CONFIG_SIGN_KEY,
		CONFIG_USE_ORG_SOURCE
	]).then(([preload, signUrl, signKeyValue, useOrg]) => {
		preloadQualityOnSearch = preload !== false;
		signServerUrl = typeof signUrl === "string" ? signUrl.trim() : "";
		signKey = typeof signKeyValue === "string" ? signKeyValue.trim() : "";
		useOrgSource = useOrg === true;
	}).catch(() => {});
	configuration?.onConfigChanged?.((keys, config) => {
		if (keys.includes(CONFIG_PRELOAD_QUALITY_ON_SEARCH)) preloadQualityOnSearch = config[CONFIG_PRELOAD_QUALITY_ON_SEARCH] !== false;
		if (keys.includes(CONFIG_USE_ORG_SOURCE)) {
			useOrgSource = config[CONFIG_USE_ORG_SOURCE] === true;
			searchCache = void 0;
		}
		if (keys.includes(CONFIG_SIGN_SERVER_URL)) signServerUrl = typeof config[CONFIG_SIGN_SERVER_URL] === "string" ? config[CONFIG_SIGN_SERVER_URL].trim() : "";
		if (keys.includes(CONFIG_SIGN_KEY)) signKey = typeof config[CONFIG_SIGN_KEY] === "string" ? config[CONFIG_SIGN_KEY].trim() : "";
	});
	var lastErrorNotifyAt = 0;
	var ERROR_NOTIFY_INTERVAL = 5e3;
	function showErrorToast(message) {
		try {
			const p = app?.showMessage?.(message, { type: "error" });
			if (p && typeof p.catch === "function") p.catch(() => {});
		} catch (err) {
			console.error("[gdstudio] Failed to show error toast:", err);
		}
	}
	function notifyHttpError(statusCode, source) {
		const now = Date.now();
		if (now - lastErrorNotifyAt < ERROR_NOTIFY_INTERVAL) return;
		lastErrorNotifyAt = now;
		showErrorToast(`GD音乐台接口异常${source ? ` [${source}]` : ""}：HTTP ${statusCode}，请稍后重试`);
	}
	function notifyNetworkError(source) {
		const now = Date.now();
		if (now - lastErrorNotifyAt < ERROR_NOTIFY_INTERVAL) return;
		lastErrorNotifyAt = now;
		showErrorToast(`GD音乐台接口连接失败${source ? ` [${source}]` : ""}，请检查网络后重试`);
	}
	function notifySignServerMissing(source) {
		const now = Date.now();
		if (now - lastErrorNotifyAt < ERROR_NOTIFY_INTERVAL) return;
		lastErrorNotifyAt = now;
		showErrorToast(`GD音乐台${source ? ` [${source}]` : ""} 音源当前不可用`);
	}
	function buildQuery(obj) {
		const parts = [];
		for (const key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) {
			const val = obj[key];
			if (val != null) parts.push(encodeURIComponent(key) + "=" + encodeURIComponent(String(val)));
		}
		return parts.join("&");
	}
	function qualityToBr(quality) {
		switch (quality) {
			case "128k": return 128;
			case "192k": return 192;
			case "320k": return 320;
			case "flac": return 740;
			case "flac24bit": return 999;
			case "wav": return 999;
			case "ape": return 999;
			case "dolby": return 999;
			case "master": return 999;
			default: return null;
		}
	}
	function brToQuality(br) {
		if (br >= 999) return "flac24bit";
		if (br >= 740) return "flac";
		if (br >= 320) return "320k";
		if (br >= 192) return "192k";
		return "128k";
	}
	function buildQualitysFromBr(br) {
		const qs = { "128k": { sizeStr: null } };
		if (br >= 192) qs["192k"] = { sizeStr: null };
		if (br >= 320) qs["320k"] = { sizeStr: null };
		if (br >= 740) qs.flac = { sizeStr: null };
		if (br >= 999) qs.flac24bit = { sizeStr: null };
		return qs;
	}
	function buildInitialQualitys() {
		return { "128k": { sizeStr: null } };
	}
	function shouldShowInitialQuality(source) {
		return preloadQualityOnSearch;
	}
	function getResponsePreview(data) {
		if (typeof data === "string") return data.slice(0, 800);
		try {
			return JSON.stringify(data).slice(0, 800);
		} catch (_err) {
			return String(data).slice(0, 800);
		}
	}
	function bodyPreview(body, length = 500) {
		try {
			return (typeof body === "string" ? body : JSON.stringify(body)).slice(0, length);
		} catch {
			return String(body).slice(0, length);
		}
	}
	function logSearchResponse(source, data) {
		const preview = (Array.isArray(data) ? data.slice(0, 3) : []).map((item) => ({
			id: String(item.id || ""),
			name: String(item.name || ""),
			artist: item.artist,
			album: item.album,
			pic_id: item.pic_id,
			lyric_id: item.lyric_id
		}));
		console.log(`[gdstudio] search response [${source}] first3: ${JSON.stringify(preview)}`);
	}
	function buildLyricInfo(musicInfo, lyric, tlyric) {
		return {
			lyric,
			tlyric: tlyric || null,
			rlyric: null,
			awlyric: null,
			name: String(musicInfo.name || ""),
			singer: String(musicInfo.singer || ""),
			interval: musicInfo.interval || null
		};
	}
	function formatInterval(seconds) {
		if (!seconds || +seconds <= 0) return null;
		const h = Math.floor(+seconds / 3600);
		const m = Math.floor(+seconds % 3600 / 60);
		const s = Math.floor(+seconds % 60);
		if (h > 0) return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
		return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
	}
	function parseArtist(artist) {
		if (Array.isArray(artist)) return artist.join("、");
		if (artist == null) return "";
		return String(artist).split(/[、&_;/,，|]/).map((s) => s.trim()).filter(Boolean).join("、");
	}
	function getOptionalResourceId(value) {
		if (typeof value !== "string" && typeof value !== "number") return null;
		return String(value).trim() || null;
	}
	var resourceIdGettingPromises = /* @__PURE__ */ new Map();
	function hasOwnResourceId(meta, key) {
		return !!meta && Object.hasOwn(meta, key);
	}
	async function persistMigratedResourceIds(source, musicId, resourceIds) {
		const gdSource = toGdSource(source);
		if (!gdSource || !musicList?.getAllUserLists || !musicList?.getListMusics || !musicList?.listAction) return;
		const allLists = await musicList.getAllUserLists();
		const listInfos = [
			allLists.defaultList,
			allLists.loveList,
			allLists.lastPlayList,
			...allLists.userList
		];
		const expectedMusicId = buildMusicId(gdSource, musicId);
		const visitedListIds = /* @__PURE__ */ new Set();
		const updates = [];
		for (const listInfo of listInfos) {
			const listId = String(listInfo?.id || "");
			if (!listId || visitedListIds.has(listId)) continue;
			visitedListIds.add(listId);
			let musics;
			try {
				musics = await musicList.getListMusics(listId);
			} catch (err) {
				console.warn(`[gdstudio] Failed to read list ${listId} during resource ID migration:`, err);
				continue;
			}
			for (const targetMusic of musics) {
				if (targetMusic.isLocal || getOptionalResourceId(targetMusic.id) !== expectedMusicId) continue;
				const targetMeta = targetMusic.meta;
				if (!targetMeta || typeof targetMeta.source !== "string" || toGdSource(targetMeta.source) !== gdSource) continue;
				const nextMeta = { ...targetMeta };
				let changed = false;
				if (!hasOwnResourceId(targetMeta, "_picId")) {
					nextMeta._picId = resourceIds.picId;
					changed = true;
				}
				if (!hasOwnResourceId(targetMeta, "_lyricId")) {
					nextMeta._lyricId = resourceIds.lyricId;
					changed = true;
				}
				if (!changed) continue;
				nextMeta._gdResourceVersion = 1;
				updates.push({
					id: listId,
					musicInfo: {
						...targetMusic,
						meta: nextMeta
					}
				});
			}
		}
		for (let index = 0; index < updates.length; index += 50) await musicList.listAction({
			action: "list_music_update",
			data: updates.slice(index, index + 50)
		});
		if (updates.length) console.log(`[gdstudio] Migrated resource IDs for ${source}:${musicId} in ${updates.length} list item(s)`);
	}
	async function ensureResourceIds(source, musicInfo, requiredType) {
		await configReady;
		const meta = musicInfo.meta;
		const hadPicId = hasOwnResourceId(meta, "_picId");
		const hadLyricId = hasOwnResourceId(meta, "_lyricId");
		const currentIds = {
			picId: getOptionalResourceId(meta?._picId),
			lyricId: getOptionalResourceId(meta?._lyricId)
		};
		if (requiredType === "pic" && hadPicId || requiredType === "lyric" && hadLyricId) return currentIds;
		const musicId = getRawMusicId(musicInfo);
		const gdSource = toGdSource(source);
		if (!gdSource || !musicId) throw new Error(`[${source}] Cannot migrate resource IDs for ${musicId || "unknown music"}`);
		const cacheKey = buildResourceCacheKey(gdSource, musicId);
		let getting = resourceIdGettingPromises.get(cacheKey);
		if (!getting) {
			getting = (async () => {
				const queryName = typeof musicInfo.name === "string" ? musicInfo.name.trim() : "";
				if (!queryName) throw new Error(`[${source}] Cannot migrate resource IDs without a music name`);
				const searchData = await apiCall({
					types: "search",
					count: "50",
					source,
					pages: "1",
					name: queryName
				});
				const exactMusic = (Array.isArray(searchData) ? searchData : []).find((item) => getOptionalResourceId(item.id) === musicId);
				if (!exactMusic) throw new Error(`[${source}] Cannot find exact music ${musicId} while migrating resource IDs`);
				const resolvedIds = {
					picId: getOptionalResourceId(exactMusic.pic_id),
					lyricId: getOptionalResourceId(exactMusic.lyric_id)
				};
				await persistMigratedResourceIds(source, musicId, resolvedIds).catch((err) => {
					console.error(`[gdstudio] Failed to persist resource IDs for ${source}:${musicId}:`, err);
				});
				return resolvedIds;
			})().finally(() => {
				resourceIdGettingPromises.delete(cacheKey);
			});
			resourceIdGettingPromises.set(cacheKey, getting);
		}
		const resolvedIds = await getting;
		const mergedIds = {
			picId: hadPicId ? currentIds.picId : resolvedIds.picId,
			lyricId: hadLyricId ? currentIds.lyricId : resolvedIds.lyricId
		};
		if (meta) {
			if (!hadPicId) meta._picId = mergedIds.picId;
			if (!hadLyricId) meta._lyricId = mergedIds.lyricId;
			meta._gdResourceVersion = 1;
		}
		return mergedIds;
	}
	function buildMusicInfo(item, source, actualBr, picUrl) {
		const now = Date.now();
		let interval = null;
		if (item.duration || item.interval) {
			const dur = Number(item.duration || item.interval);
			if (dur > 0) interval = formatInterval(dur);
		}
		return {
			id: buildMusicId(getGdSource(source), String(item.id)),
			name: String(item.name || ""),
			singer: parseArtist(item.artist),
			interval,
			isLocal: false,
			meta: {
				musicId: String(item.id),
				albumName: String(item.album || ""),
				picUrl: picUrl || null,
				source,
				qualitys: actualBr ? buildQualitysFromBr(actualBr) : shouldShowInitialQuality(source) ? buildInitialQualitys() : {},
				_picId: getOptionalResourceId(item.pic_id),
				_lyricId: getOptionalResourceId(item.lyric_id),
				_gdResourceVersion: 1,
				createTime: now,
				updateTime: now,
				posTime: now
			}
		};
	}
	var picGettingPromises = /* @__PURE__ */ new Map();
	function buildResourceCacheKey(source, musicId) {
		return `${isOrgSource(source) ? "org" : "main"}|${source}|${musicId}`;
	}
	function getMusicInfoSource(musicInfo) {
		return String(musicInfo.meta?.source || "");
	}
	async function updatePlayingMusicInfo(source, hostMusicId, update) {
		try {
			for (let retry = 0; retry < 12; retry++) {
				const list = (await player?.getPlayInfo?.())?.list;
				if (Array.isArray(list)) {
					const item = list.find((listItem) => {
						const musicInfo = listItem?.musicInfo;
						return musicInfo && String(musicInfo.id || "") === hostMusicId && getMusicInfoSource(musicInfo) === source;
					});
					const currentMusicInfo = item?.musicInfo;
					const listId = item?.listId;
					if (currentMusicInfo && listId) {
						update(currentMusicInfo);
						await musicList?.listAction?.({
							action: "list_music_update",
							data: [{
								id: listId,
								musicInfo: currentMusicInfo
							}]
						});
						return;
					}
				}
				await new Promise((resolve) => {
					setTimeout(resolve, 250);
				});
			}
		} catch (err) {
			console.error("[gdstudio] Failed to update playing music info:", err);
		}
	}
	async function updatePlayingMusicQuality(source, hostMusicId, actualBr) {
		await updatePlayingMusicInfo(source, hostMusicId, (musicInfo) => {
			const targetMeta = musicInfo.meta;
			if (targetMeta) targetMeta.qualitys = buildQualitysFromBr(actualBr);
		});
	}
	async function updatePlayingMusicPic(source, hostMusicId, picUrl) {
		await updatePlayingMusicInfo(source, hostMusicId, (musicInfo) => {
			const targetMeta = musicInfo.meta;
			if (targetMeta) targetMeta.picUrl = picUrl;
		});
	}
	function prefetchPlaybackPic(source, rawMusicId, hostMusicId, musicInfo) {
		const meta = musicInfo.meta;
		fetchMusicPic(source, musicInfo).then((url) => {
			if (meta) meta.picUrl = url;
			updatePlayingMusicPic(source, hostMusicId, url);
		}).catch((err) => {
			console.error(`[gdstudio] Failed to fetch pic for ${source}:${rawMusicId}:`, err);
		});
	}
	async function fetchMusicPic(source, musicInfo) {
		await configReady;
		const musicId = getRawMusicId(musicInfo);
		const cacheKey = buildResourceCacheKey(source, musicId);
		const getting = picGettingPromises.get(cacheKey);
		if (getting) return getting;
		const promise = (async () => {
			const { picId } = await ensureResourceIds(source, musicInfo, "pic");
			if (!picId) throw new Error(`[${source}] No pic_id available for ${musicId}`);
			const data = await apiCall({
				types: "pic",
				source,
				id: picId,
				size: "500"
			});
			console.log(`[gdstudio] pic response [${source}] musicId=${musicId} picId=${picId}: ${getResponsePreview(data)}`);
			if (data && data.url) return String(data.url);
			throw new Error("No pic URL for pic_id " + picId);
		})().finally(() => {
			picGettingPromises.delete(cacheKey);
		});
		picGettingPromises.set(cacheKey, promise);
		return promise;
	}
	async function detectMainApiQuality(source, musicId) {
		try {
			const data = await apiCall({
				types: "url",
				source,
				id: musicId,
				br: "999"
			});
			if (data && data.url) return data.br != null ? Number(data.br) : 128;
		} catch (_err) {}
		return 128;
	}
	async function hydrateMainApiSearchItem(source, rawItem, musicInfo) {
		const meta = musicInfo.meta;
		if (meta._detailsLoaded) return;
		const musicId = String(rawItem.id || musicInfo.id);
		const [actualBr, picUrl] = await Promise.all([preloadQualityOnSearch ? detectMainApiQuality(source, musicId) : Promise.resolve(null), fetchMusicPic(source, musicInfo).catch(() => null)]);
		if (actualBr) meta.qualitys = buildQualitysFromBr(actualBr);
		if (picUrl) meta.picUrl = picUrl;
		meta._detailsLoaded = true;
	}
	async function apiCallMainApi(params) {
		const body = buildQuery(params);
		let resp;
		try {
			resp = await request(MAIN_API_URL + "?" + body, {
				method: "GET",
				timeout: 15e3,
				headers: {
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
					"X-Requested-With": "XMLHttpRequest",
					Referer: "https://music.gdstudio.org/"
				}
			});
		} catch (err) {
			console.error(`[gdstudio] request failed [${params.source}] types=${params.types}:`, err);
			notifyNetworkError(params.source);
			throw err;
		}
		const statusCode = resp.statusCode ?? "?";
		if (statusCode !== 200) {
			console.error(`[gdstudio] non-200 response (${statusCode}):`, typeof resp.body === "string" ? resp.body.slice(0, 500) : JSON.stringify(resp.body).slice(0, 500));
			notifyHttpError(statusCode, params.source);
			throw new Error(`GDStudio API returned HTTP ${statusCode}`);
		}
		const data = typeof resp.body === "string" ? JSON.parse(resp.body) : resp.body;
		if (params.types === "search") logSearchResponse(params.source, data);
		return data;
	}
	async function apiCallOrg(params) {
		const source = String(params.source || "");
		if (!signServerUrl) {
			notifySignServerMissing(source);
			throw new Error("当前音源尚未配置");
		}
		const signParams = {
			op: String(params.types),
			source
		};
		for (const key of Object.keys(params)) {
			if (key === "types" || key === "source") continue;
			if (params[key] != null) signParams[key === "pages" ? "page" : key] = String(params[key]);
		}
		const signHeaders = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" };
		if (signKey) signHeaders.Authorization = `Bearer ${signKey}`;
		let signResp;
		try {
			signResp = await request(signServerUrl.replace(/\/+$/, "") + "/sign?" + buildQuery(signParams), {
				method: "GET",
				headers: signHeaders,
				timeout: 8e3
			});
		} catch (err) {
			console.error(`[gdstudio] sign request failed [${source}]:`, err);
			notifyNetworkError(source);
			throw err;
		}
		if (signResp.statusCode !== 200) {
			console.error(`[gdstudio] sign server non-200 (${signResp.statusCode}):`, bodyPreview(signResp.body, 300));
			notifyHttpError(signResp.statusCode ?? "?", source);
			throw new Error(`签名服务器返回 ${signResp.statusCode}`);
		}
		let signData;
		try {
			signData = typeof signResp.body === "string" ? JSON.parse(signResp.body) : signResp.body;
		} catch {
			throw new Error("签名服务器响应解析失败: " + JSON.stringify(signResp.body).slice(0, 200));
		}
		if (!signData.ok || !signData.req || !signData.req.url) throw new Error(`签名失败: ${signData.error || "未知错误"}`);
		const req = signData.req;
		let resp;
		try {
			resp = await request(req.url, {
				method: req.method || "POST",
				headers: req.headers,
				binary: req.body != null ? await dataConverter(String(req.body), "utf-8", "binary") : void 0,
				timeout: 15e3
			});
		} catch (err) {
			console.error(`[gdstudio] direct request failed [${source}]:`, err);
			notifyNetworkError(source);
			throw err;
		}
		const statusCode = resp.statusCode ?? "?";
		if (statusCode !== 200) {
			console.error(`[gdstudio] non-200 response (${statusCode}):`, bodyPreview(resp.body, 500));
			notifyHttpError(statusCode, source);
			throw new Error(`GDStudio upstream returned HTTP ${statusCode}`);
		}
		const data = typeof resp.body === "string" ? JSON.parse(resp.body) : resp.body;
		if (params.types === "search") logSearchResponse(params.source, data);
		return data;
	}
	async function apiCall(params) {
		await configReady;
		const source = String(params.source || "");
		const logicalSource = toGdSource(source) || source;
		const normalizedParams = source === logicalSource ? params : {
			...params,
			source: logicalSource
		};
		return isOrgSource(logicalSource) ? apiCallOrg(normalizedParams) : apiCallMainApi(normalizedParams);
	}
	var searchCache;
	async function fetchSearchBatch(source, name, page, count) {
		let lastError = null;
		for (let retry = 0; retry < 2; retry++) try {
			const data = await apiCall({
				types: "search",
				count: String(count),
				source,
				pages: String(page),
				name
			});
			if (data && data.error) {
				lastError = String(data.error);
				break;
			}
			const rawList = Array.isArray(data) ? data : [];
			if (rawList.length > 0) return rawList;
			if (retry < 1) await new Promise((resolve) => {
				setTimeout(resolve, 300);
			});
		} catch (err) {
			lastError = err instanceof Error ? err.message : String(err);
			console.error(`[gdstudio] search request failed [${source}]:`, err);
			notifyNetworkError(source);
			if (retry < 1) await new Promise((resolve) => {
				setTimeout(resolve, 500);
			});
		}
		throw new Error(lastError || "搜索返回空结果(可能是 API 限流,请稍后重试)");
	}
	async function musicSearch(params) {
		await configReady;
		const source = params.source;
		const name = params.name;
		const artist = params.artist;
		const page = params.page || 1;
		const limit = Math.min(params.limit || 20, 50);
		const fetchCount = limit * 3;
		if (isOrgSource(source) && !signServerUrl) {
			notifySignServerMissing(source);
			throw new Error("当前音源尚未配置");
		}
		const searchKey = JSON.stringify([
			source,
			name,
			artist || "",
			limit
		]);
		if (searchCache?.key !== searchKey) {
			const queryName = artist ? name + " " + artist : name;
			searchCache = {
				key: searchKey,
				pagination: createSearchPagination(async (apiPage) => (await fetchSearchBatch(source, queryName, apiPage, fetchCount)).map((raw) => ({
					raw,
					musicInfo: buildMusicInfo(raw, source)
				})), (item) => item.musicInfo.id, (error) => {
					console.warn(`[gdstudio] more search results unavailable [${source}], retry on next page:`, error);
				})
			};
		}
		const { list, total } = await searchCache.pagination.getPage(page, limit);
		if (!isOrgSource(source)) await Promise.all(list.map(async (item) => {
			await hydrateMainApiSearchItem(source, item.raw, item.musicInfo);
		}));
		return {
			list: list.map((item) => item.musicInfo),
			total,
			page,
			limit
		};
	}
	async function musicUrl(params) {
		const source = params.source;
		const musicInfo = params.musicInfo;
		const quality = params.quality;
		if (shouldRejectLegacySource(source)) {
			await promptLegacyMigration();
			throw new Error("GDSTUDIO_IDENTITY_MIGRATION_REQUIRED");
		}
		const hostMusicId = String(musicInfo.id || "");
		const musicId = getRawMusicId(musicInfo);
		prefetchPlaybackPic(source, musicId, hostMusicId, musicInfo);
		const allBrs = [
			999,
			740,
			320,
			192,
			128
		];
		let brsToTry = allBrs;
		if (quality) {
			const preferredBr = qualityToBr(quality);
			if (preferredBr) brsToTry = allBrs.filter((br) => br <= preferredBr);
		}
		let lastError = null;
		for (let j = 0; j < brsToTry.length; j++) {
			const br = brsToTry[j];
			try {
				const data = await apiCall({
					types: "url",
					source,
					id: musicId,
					br: String(br)
				});
				if (data && data.url) {
					const actualBr = data.br != null ? Number(data.br) : br;
					const meta = musicInfo.meta;
					if (meta) meta.qualitys = buildQualitysFromBr(actualBr);
					updatePlayingMusicQuality(source, hostMusicId, actualBr);
					return {
						url: String(data.url),
						quality: brToQuality(actualBr)
					};
				}
			} catch (err) {
				lastError = err;
			}
		}
		if (lastError) console.error(`[gdstudio] No URL available for ${source}:${musicId}:`, lastError.message);
		throw new Error(`[${source}] No URL available for ${musicId}${lastError ? `: ${lastError.message}` : ""}`);
	}
	async function musicPic(params) {
		const source = params.source;
		const musicInfo = params.musicInfo;
		const musicId = getRawMusicId(musicInfo);
		return fetchMusicPic(source, musicInfo).catch((err) => {
			console.error(`[gdstudio] Failed to fetch pic for ${source}:${musicId}:`, err);
			throw err;
		});
	}
	async function musicLyric(params) {
		const source = params.source;
		const musicInfo = params.musicInfo;
		const musicId = getRawMusicId(musicInfo);
		try {
			const { lyricId } = await ensureResourceIds(source, musicInfo, "lyric");
			if (!lyricId) throw new Error(`[${source}] No lyric_id available for ${musicId}`);
			const data = await apiCall({
				types: "lyric",
				source,
				id: String(lyricId)
			});
			const lyric = typeof data?.lyric === "string" ? data.lyric.trim() : "";
			if (!lyric) throw new Error(`[${source}] No lyric available for ${String(lyricId)}`);
			return buildLyricInfo(musicInfo, lyric, typeof data?.tlyric === "string" && data.tlyric.trim() ? data.tlyric : null);
		} catch (err) {
			console.error(`[gdstudio] Failed to get lyric [${source}] musicId=${musicId}:`, err);
			throw err;
		}
	}
	registerResourceAction({
		musicSearch,
		musicUrl,
		musicPic,
		musicLyric
	});
	setupMigrationCommands().catch((err) => {
		console.error("[gdstudio] Failed to register migration commands:", err);
	});
	setupSignServerSettingsCommand().catch((err) => {
		console.error("[gdstudio] Failed to register sign server settings command:", err);
	});
	showUpdateNotice().catch((err) => {
		console.error("[gdstudio] Failed to show update notice:", err);
	});
	//#endregion
})();
